import './_header.html';

Template.cooperateHeader.onRendered(function () {
	$('[data-toggle="dropdown"]').dropdown();
});
