/**
 * Created by malith on 04/07/17.
 */
import './_menu.html';
/** Rendered Initialisation */
Template.casualMenuBar.onRendered(function () {
	var tpl = this;
	// tpl.$(".fooJqueryPlugin").initialise()

});


/** Template Helpers */
/*
 Template.executiveMenuBar.helpers({
 // Register template helpers with arguments {{foo "John" "Doe" title="President"}}
 // foo: function (first, last, keyword) { return keyword.hash.title + firstName + " " + lastName; }

 });
 */

/** jQuery Events */

/*
 Template.executiveMenuBar.events({
 // Fires when 'accept' is clicked or focused, or a key is pressed
 // 'click .accept, focus .accept, keypress': function (event) { ... }

 });
 */

/** Set-Up Subscriptions and Registrations */
/*
 Template.executiveMenuBar.onCreated(function () {
 var tpl = this;
 // set up subscriptions, local reactive variables, registrations
 // tpl.subscribe("notifications");
 });
 */


/** De-Registrations */

/*
 Template.executiveMenuBar.onDestroyed(function () {
 var tpl = this;
 // de-registration

 });
 */
 