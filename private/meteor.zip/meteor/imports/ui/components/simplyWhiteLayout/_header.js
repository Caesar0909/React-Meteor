import './_header.html';

Template.simplyWhite.onRendered(function () {
	$('[data-toggle="dropdown"]').dropdown();
});
