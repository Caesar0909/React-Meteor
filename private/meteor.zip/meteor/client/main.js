// Set origin of layout to body
BlazeLayout.setRoot('body');

import '/imports/startup/client';
import '/imports/startup/both';
