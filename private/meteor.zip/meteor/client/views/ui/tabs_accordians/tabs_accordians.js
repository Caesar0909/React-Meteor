/**
 * Created by dinos on 10/07/15.
 */

/** Rendered Initialisation */
Template.tabs_accordian.onRendered(function () {
	$.Pages.reponsiveTabs();
});